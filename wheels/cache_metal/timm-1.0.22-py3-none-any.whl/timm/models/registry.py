from ._registry import *

import warnings
warnings.warn(f"Importing from {__name__} is deprecated, please import via timm.models", FutureWarning)
